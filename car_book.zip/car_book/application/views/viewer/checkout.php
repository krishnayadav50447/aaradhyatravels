<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

<section class="content_sec bgc_1">

</section>

<script type="text/javascript">
var base_url="<?php echo base_url(); ?>";


</script>