<div class="footer_bottom">
	<div class="container">
		<div class="row mx-lg-0">
			<div class="col-12 px-lg-0">
				<div class="d-lg-flex d-md-flex justify-content-between">
					<p class="fs_14 mb-lg-0 mb-md-0 mb-2">Copyright &copy; <?php echo site_title();?>. All Right Reserved</p>
				</div>
			</div>
		</div>
	</div>
</div>


<script type="text/javascript" src="<?php echo base_url(); ?>/viewer_assets/jquery/wow.js"></script>
<script type="text/javascript" src="<?php echo base_url('viewer_assets/jquery/common_js.js?v=').get_version(); ?>"></script>

<link rel="stylesheet" type="text/css" href="<?php echo base_api("assets/webinaToastModal/webinajs.css"); ?>">
<script type="text/javascript" src="<?php echo base_api("assets/webinaToastModal/webinajs.js"); ?>"></script>


</body>
</html>