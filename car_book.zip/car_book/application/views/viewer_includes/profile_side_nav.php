<!-- <ul>
	<li><a href="<?php //echo base_url('dashboard'); ?>"><span><i class="fa-solid fa-gauge"></i></span> Dashboard</a></li>
	<li><a href="<?php //echo base_url('profile'); ?>"><span><i class="fa-solid fa-address-card"></i></span> Profile</a></li>
	<li><a href="<?php //echo base_url('transaction'); ?>"><span><i class="fa-solid fa-clock-rotate-left"></i></span> Booking History</a></li>
	<li><a href="<?php //echo base_url('support'); ?>"><span><i class="fa-solid fa-phone"></i></span> Support</a></li>
	<li><a href="<?php //echo base_url('setting'); ?>"><span><i class="fa-solid fa-screwdriver-wrench"></i></span> Setting</a></li>
</ul> -->